#include <stdint.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <linux/types.h>
#include "oled.h"
#include <unistd.h>
#include <string.h>

static char string[100] = {0,};
static char isClear = 0;
extern char size;
static char row = 2;
static char col = -1;
static char commd[20] = {0,};
static char  timer = 0;
static char isInit = 0;
static char dc_gpio = 169;
static char res_gpio = 167;
static char spidev[100] = {0, };

static void print_usage(const char *prog)
{
	printf("Usage: %s [show string] [-tpsrcClfbi]\n", prog);
	puts(" -i --init    must be used when oled begin work\n"
		"  -t --timer   show string after timer , 1000 = 1s, maxtime = 10000)\n"
	     "  -p --position    show in this position (x,y), default in frame center\n"
	     "  -s --size    font size , 16 or 8, default 16\n"
	     "  -b --rollback   frame rollback\n"
	     "  -r --row      row number in position 1~8\n"
	     "  -C --px-column   column number in position 1~128px \n"
	     "  -c --column   column number in position 1~16\n"
	     "  -f --frame    clear fream, then show string \n"
	     "  --DCgpio    set DC pin ,default 169\n"
	     "  --RESgpio    set RES pin ,default 167 \n"
	     "  --spidev    set spidev path ,default /dev/spidev1.0 \n");
	exit(1);
}


static void parse_opts(int argc, char *argv[])
{
	if( argv[1][0] != '-')
		strcpy(string, argv[1]);

	strcpy(spidev, "/dev/spidev1.0");
	while (1) {
		static const struct option lopts[] = {
			{ "timer",	 1, 0, 't' },
			{ "position",1, 0, 'p' },
			{ "size",    1, 0, 's' },
			{ "row",     1, 0, 'r' },
			{ "column",  1, 0, 'c' },
			{ "pxcolumn",1, 0, 'C' },
			{ "frame",   0, 0, 'f' },
			{ "rollback",0, 0, 'b' },
			{ "rollface",0, 0, 'B' },
			{ "init",	 0, 0, 'i' },
			{ "DCgpio",	 1, 0, 'D' },
			{ "spidev",	 1, 0, 'S' },
			{ "RESgpio", 1, 0, 'R' },
			{ NULL, 0, 0, 0 },
		};
		int c;

		c = getopt_long(argc, argv, "t:p:s:r:c:C:D:S:R:fbBi", lopts, NULL);

		if (c == -1)
			break;

		switch (c) {
		case 't':
			timer = atoi(optarg)*1000;
			break;
		case 'p':
			break;
		case 's':
			size = atoi(optarg);
			if( size != 16 && size != 8)
				print_usage(argv[0]);
			break;
		case 'r':
			row = atoi(optarg);
			break;
		case 'c':
			col = atoi(optarg)* 8;
			break;
		case 'C':
			col = atoi(optarg);
			break;
		case 'f':
			isClear = 1;
			break;
		case 'i':
			isInit = 1;
			break;
		case 'b':
			{
				int k = 0;
				while(commd[k] != '\0') k++;
				commd[k] = 0xA0;
				commd[k+1] = 0xC0;
			}
			break;
		case 'B':
			{
				int k = 0;
				while(commd[k] != '\0') k++;
				commd[k] = 0xA1;
				commd[k+1] = 0xC8;
			}
			break;
		case 'D':
			dc_gpio = atoi(optarg);
			break;
		case 'S':
			strcpy(spidev, optarg);
			break;
		case 'R':
			res_gpio =atoi(optarg);
			break;
		default:
			print_usage(argv[0]);
			break;
		}
	}
	if(col == 255)
		col = (128-strlen(string)*8)/2;
}


int main(int argc, char *argv[])
{
	parse_opts(argc, argv);
	delay_ms(timer);

	if( init_fd(dc_gpio, res_gpio, spidev) == -1)
		exit(1);
	if(argc == 1 )
		print_usage(argv[0]);

	if( isInit == 1 )
		OLED_Init();

	if(isClear == 1){
		OLED_Clear();
	}

	int j = 0;
	while(commd[j] != 0){
		OLED_WR_Byte(commd[j],OLED_CMD);
		j++;
	}


	if( string[0] != '\0')
		OLED_ShowString(col, row, string);
	
	OLED_END();
	return 0;
}
