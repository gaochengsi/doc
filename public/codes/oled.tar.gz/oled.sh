#!/bin/bash

PIN="--DCgpio=166 --RESgpio=169"

./oled Hello,friends -i -b "$PIN"

./oled Hello,friends -r 1 -f -t 1000 "$PIN" 
./oled I\`m\ Radxa -r 3 "$PIN"
